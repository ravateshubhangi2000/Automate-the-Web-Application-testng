package selenium.TestNgPracticeproject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class AppTest {

    WebDriver wd;

    @BeforeMethod
    public void setup() {
        // Register the webdriver => browser vendor
        WebDriverManager.chromedriver().setup();
        // Creating an object for the WebDriver
        wd = new ChromeDriver();
        // Maximize the browser window
        wd.manage().window().maximize();
    }

    @Test
    public void testLoginAmazon() throws InterruptedException {
        // Login Automation on Amazon
        loginAmazon();

        // Add assertions or verifications if needed
    }

    @Test
    public void testRegisterAmazon() throws InterruptedException {
        // Registration Automation on Amazon
        registerAmazon();

        // Add assertions or verifications if needed
    }

    @AfterMethod
    public void tearDown() throws InterruptedException {
        // Close browser
        Thread.sleep(2000);
        wd.quit();
    }

    public void loginAmazon() {
        // Go to the Amazon website
        wd.get("https://www.amazon.in/");

        // Click on the "Account & Lists" link to access the login page
        WebDriverWait wait = new WebDriverWait(wd, 20);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("nav-link-accountList"))).click();

        // Enter login credentials
        wd.findElement(By.id("ap_email")).sendKeys("shubhangi@gmail.com");
        wd.findElement(By.id("continue")).click();
        
        // Wait for password field to be visible
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ap_password"))).sendKeys("12345678");

        // Click on the "Sign-In" button
        wd.findElement(By.id("signInSubmit")).click();
    }

    public void registerAmazon() {
        // Go to the Amazon website
        wd.get("https://www.amazon.in/");

        // Click on the "Account & Lists" link to access the registration page
        WebDriverWait wait = new WebDriverWait(wd, 20);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("nav-link-accountList"))).click();

        // Click on the "Create your Amazon account" button
        wait.until(ExpectedConditions.elementToBeClickable(By.id("createAccountSubmit"))).click();

        // Enter registration details
        wd.findElement(By.id("ap_customer_name")).sendKeys("shubhangi");
        wd.findElement(By.id("ap_phone_number")).sendKeys("1010101010");
        wd.findElement(By.id("ap_email")).sendKeys("shubhangi@gmail.com");
        wd.findElement(By.id("ap_password")).sendKeys("12345678");

        // Click on the "Continue" button to complete registration
        wd.findElement(By.xpath("//*[@id=\"continue\"]")).click();
    }
}
